"""
Helper utilities for bot operations
"""

import os
import logging
import asyncio
from telegram import Update, Document

logger = logging.getLogger(__name__)

async def cleanup_temp_file(file_path: str):
    """Clean up temporary file"""
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            logger.info(f"Cleaned up temp file: {file_path}")
    except Exception as e:
        logger.error(f"Error cleaning up temp file {file_path}: {e}")

async def send_document_to_user(update: Update, file_path: str, caption: str = None):
    """Send document file to user"""
    try:
        if not os.path.exists(file_path):
            await update.message.reply_text("❌ File tidak ditemukan.")
            return
        
        file_size = os.path.getsize(file_path)
        
        # Telegram file size limit is 50MB
        if file_size > 50 * 1024 * 1024:
            await update.message.reply_text(
                f"❌ File terlalu besar ({file_size} bytes). "
                f"Maksimum 50MB."
            )
            return
        
        with open(file_path, 'rb') as file:
            await update.message.reply_document(
                document=file,
                caption=caption,
                filename=os.path.basename(file_path)
            )
        
        logger.info(f"Document sent: {file_path}")
        
    except Exception as e:
        logger.error(f"Error sending document: {e}")
        await update.message.reply_text(f"❌ Error mengirim file: {str(e)}")

def ensure_temp_directory():
    """Ensure temp directory exists"""
    temp_dir = "temp"
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)
        logger.info("Created temp directory")

def validate_file_extension(filename: str, allowed_extensions: list) -> bool:
    """Validate file extension"""
    if not filename:
        return False
    
    file_ext = os.path.splitext(filename)[1].lower()
    return file_ext in [ext.lower() for ext in allowed_extensions]

def sanitize_filename(filename: str) -> str:
    """Sanitize filename for safe file operations"""
    # Remove dangerous characters
    dangerous_chars = ['/', '\\', ':', '*', '?', '"', '<', '>', '|']
    sanitized = filename
    
    for char in dangerous_chars:
        sanitized = sanitized.replace(char, '_')
    
    # Limit length
    if len(sanitized) > 100:
        name, ext = os.path.splitext(sanitized)
        sanitized = name[:100-len(ext)] + ext
    
    return sanitized

def format_file_size(size_bytes: int) -> str:
    """Format file size in human readable format"""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"

def is_safe_file_type(filename: str) -> bool:
    """Check if file type is safe to process"""
    dangerous_extensions = ['.exe', '.bat', '.cmd', '.scr', '.pif', '.com']
    file_ext = os.path.splitext(filename)[1].lower()
    return file_ext not in dangerous_extensions

async def log_user_activity(user_id: int, activity: str, details: str = None):
    """Log user activity"""
    try:
        from bot.database import log_file_operation
        log_file_operation(user_id, activity, details or "N/A", "completed")
    except Exception as e:
        logger.error(f"Error logging user activity: {e}")

def extract_phone_numbers(text: str) -> list:
    """Extract phone numbers from text"""
    import re
    
    # Indonesian phone number patterns
    patterns = [
        r'\+62[0-9]{8,13}',  # +62 format
        r'62[0-9]{8,13}',    # 62 format
        r'0[0-9]{8,13}',     # 0 format
        r'[0-9]{10,14}'      # General numbers
    ]
    
    phone_numbers = []
    for pattern in patterns:
        matches = re.findall(pattern, text)
        phone_numbers.extend(matches)
    
    # Clean and normalize phone numbers
    cleaned_numbers = []
    for number in phone_numbers:
        # Remove non-digit characters
        clean_number = ''.join(filter(str.isdigit, number))
        
        # Normalize to 62 format
        if clean_number.startswith('0'):
            clean_number = '62' + clean_number[1:]
        elif not clean_number.startswith('62'):
            clean_number = '62' + clean_number
        
        if len(clean_number) >= 10 and len(clean_number) <= 15:
            cleaned_numbers.append(clean_number)
    
    return list(set(cleaned_numbers))  # Remove duplicates

def parse_contact_line(line: str) -> tuple:
    """Parse a line of text to extract name and phone"""
    separators = ['|', ',', ':', ';', '\t', ' - ', '  ']
    
    for sep in separators:
        if sep in line:
            parts = line.split(sep, 1)
            if len(parts) == 2:
                name = parts[0].strip()
                phone = parts[1].strip()
                
                # Clean phone number
                phone_cleaned = ''.join(filter(str.isdigit, phone))
                if phone_cleaned:
                    return name, phone_cleaned
    
    return None, None

async def create_backup_file(original_file: str) -> str:
    """Create backup of original file"""
    try:
        backup_file = original_file + '.backup'
        with open(original_file, 'rb') as src, open(backup_file, 'wb') as dst:
            dst.write(src.read())
        return backup_file
    except Exception as e:
        logger.error(f"Error creating backup: {e}")
        return None

def count_lines_in_file(file_path: str) -> int:
    """Count lines in a text file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return sum(1 for line in f)
    except Exception as e:
        logger.error(f"Error counting lines: {e}")
        return 0

def get_file_info(file_path: str) -> dict:
    """Get comprehensive file information"""
    try:
        stat = os.stat(file_path)
        return {
            'size': stat.st_size,
            'size_formatted': format_file_size(stat.st_size),
            'modified': stat.st_mtime,
            'name': os.path.basename(file_path),
            'extension': os.path.splitext(file_path)[1],
            'is_safe': is_safe_file_type(file_path)
        }
    except Exception as e:
        logger.error(f"Error getting file info: {e}")
        return {}

# Startup helper
def initialize_bot_environment():
    """Initialize bot environment"""
    ensure_temp_directory()
    logger.info("Bot environment initialized")
